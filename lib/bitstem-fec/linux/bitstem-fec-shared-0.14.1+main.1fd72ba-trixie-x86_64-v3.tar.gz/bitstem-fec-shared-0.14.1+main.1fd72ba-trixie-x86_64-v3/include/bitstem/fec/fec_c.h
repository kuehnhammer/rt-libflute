/*  Copyright (C) Bitstem GmbH
 *  All rights reserved.
 *
 *  This source code is proprietary and confidential.
 *  Unauthorized copying, distribution, or disclosure of this file,
 *  in whole or in part, is strictly prohibited unless explicitly
 *  permitted in writing by Bitstem GmbH.
 *
 *  Author: Klaus Kuehnhammer <klaus@bitstem.com>
 */

/* Stable C ABI for runtime-load (dlopen) deployment.
 *
 * Use case: a downstream process wants to ship a single binary that
 * runs both with and without the FEC codecs installed — e.g. a
 * 5GR core where Raptor / RaptorQ are licensed-feature gated.
 * The process builds against this header without taking a link-time
 * dependency on libfec.so; at first FEC use it dlopens
 * libfec.so.0 (RTLD_NOW | RTLD_LOCAL), dlsyms the entry points
 * below, and calls through function pointers.
 *
 * Why C linkage: C++ name mangling is not portable across
 * compiler / libstdc++ versions. dlsym'ing C++ class methods is
 * allowed by the language but breaks under common toolchain
 * mismatches (GCC vs Clang, libstdc++ vs libc++, version skew
 * across distributions). C linkage is the standard portable
 * pattern for this deployment shape.
 *
 * Why this is a separate header from <bitstem/fec/c_api.h>: the
 * existing c_api.h is the per-scheme test C API (Rust sweep,
 * RaptorQ bench harness). This header is the polymorphic-by-
 * scheme deployment-side ABI. Both coexist in the same library.
 *
 * For C++ in-process consumers, the supported surface remains
 * <bitstem/fec/fec.hpp> (link-time, no ABI shim).
 */

#ifndef BITSTEM_FEC_FEC_C_H
#define BITSTEM_FEC_FEC_C_H

#include <stddef.h>
#include <stdint.h>

/* Visibility marker for the C ABI exports.
 *
 * The library is built with -fvisibility=hidden so internal C++
 * symbols don't escape the dynamic-symbol table. The C ABI surface
 * MUST be marked default-visibility on the BUILD side so the
 * --version-script global: list can promote it; on the CONSUMER side
 * it's a no-op (symbols are imported from the .so via the dynamic
 * linker, no visibility attribute needed). */
#if defined(_WIN32) || defined(__CYGWIN__)
  #if defined(BITSTEM_FEC_BUILDING_SHARED)
    #define BITSTEM_FEC_C_API __declspec(dllexport)
  #elif defined(BITSTEM_FEC_USING_SHARED)
    #define BITSTEM_FEC_C_API __declspec(dllimport)
  #else
    #define BITSTEM_FEC_C_API
  #endif
#elif defined(__GNUC__) || defined(__clang__)
  #define BITSTEM_FEC_C_API __attribute__((visibility("default")))
#else
  #define BITSTEM_FEC_C_API
#endif

#ifdef __cplusplus
extern "C" {
#endif

/* ------------------------------------------------------------------
 * ABI version
 *
 * Bumped on incompatible changes to this header (signature change,
 * struct layout change, semantic change to existing functions).
 * Adding new functions at the end without changing existing ones
 * does NOT bump this number.
 *
 * The dlopener resolves bitstem_fec_c_abi_version immediately after
 * dlopen and refuses to use libraries reporting a different value
 * than the consumer was compiled against.
 * ------------------------------------------------------------------ */
#define BITSTEM_FEC_C_ABI_VERSION 1u

/* Returns the ABI version the loaded libfec.so was built against.
 * This is the only function the consumer can dlsym before knowing
 * whether the library is compatible — its signature is frozen. */
BITSTEM_FEC_C_API unsigned bitstem_fec_c_abi_version(void);

/* ------------------------------------------------------------------
 * Codec selection + parameters
 * ------------------------------------------------------------------ */

/* Mirrors bitstem::fec::Scheme. Wire-level FEC scheme identifiers
 * (RFC 5052 IANA registry) are deliberately NOT used here — this
 * enum is a codec-selection knob, not a wire identifier. */
typedef enum {
    BITSTEM_FEC_SCHEME_R10     = 0,    /* RFC 5053 R10 */
    BITSTEM_FEC_SCHEME_RAPTORQ = 1     /* RFC 6330 RaptorQ */
} bitstem_fec_scheme_t;

/* Mirrors bitstem::fec::LayoutHint. Source-block byte layout for
 * the K * T-byte source-block buffer. Only meaningful for N>1
 * (sub-block interleaving); N==1 collapses both layouts into one.
 *
 * CODEC_NATIVE: RFC 5053 §5.3.1.2 / RFC 6330 §4.4.1.2 sub-block-
 *               major layout.
 * SOURCE_ORDER: K source symbols of T bytes contiguous in source-
 *               symbol order (file-natural). Encoder + decoder
 *               agree on layout per-instance via this field.
 *
 * See <bitstem/fec/fec.hpp> for the full doc. */
typedef enum {
    BITSTEM_FEC_LAYOUT_CODEC_NATIVE = 0,
    BITSTEM_FEC_LAYOUT_SOURCE_ORDER = 1
} bitstem_fec_layout_t;

/* Encoder + Decoder configuration. Same shape as the C++
 * EncoderParams / DecoderParams. Both sides MUST use identical
 * (K, T, scheme, Al, N) for a successful round-trip (these are
 * the on-the-wire FEC OTI fields). `layout` is in-process only
 * and may differ between sender and receiver. */
typedef struct {
    uint16_t              K;
    uint16_t              T;
    bitstem_fec_scheme_t  scheme;
    uint8_t               Al;
    uint16_t              N;
    bitstem_fec_layout_t  layout;
} bitstem_fec_params_t;

/* ------------------------------------------------------------------
 * Encoder
 * ------------------------------------------------------------------ */

/* Opaque handle. */
typedef struct bitstem_fec_encoder bitstem_fec_encoder_t;

/* Construct an encoder for the given parameters. After Create, the
 * encoder has no source bound — call _reset before _encode_symbol.
 *
 * Returns NULL if:
 *   - p == NULL
 *   - Validation fails (K out of scheme range, T == 0, T % Al != 0,
 *     Al not in {1,2,4,8}, N == 0, N > T/Al)
 *   - The codec for `p->scheme` is not built into this libfec.so
 *     (build-time disable; dlsym
 *     bitstem_fec_has_scheme_<name> to probe). */
BITSTEM_FEC_C_API bitstem_fec_encoder_t*
bitstem_fec_encoder_create(const bitstem_fec_params_t* p);

BITSTEM_FEC_C_API void bitstem_fec_encoder_destroy(bitstem_fec_encoder_t* enc);

/* Bind a new K-source-symbol set. Bytes interpreted per
 * params->layout. Pre-condition: src_len == K * T. Asserted in
 * debug; UB on size mismatch in release. */
BITSTEM_FEC_C_API void bitstem_fec_encoder_reset(
    bitstem_fec_encoder_t* enc,
    const uint8_t* src, size_t src_len);

/* Emit the symbol with `esi`. `out_len` MUST equal T. */
BITSTEM_FEC_C_API void bitstem_fec_encoder_encode_symbol(
    bitstem_fec_encoder_t* enc,
    uint32_t esi,
    uint8_t* out, size_t out_len);

/* ------------------------------------------------------------------
 * Decoder
 * ------------------------------------------------------------------ */

/* Opaque handle. */
typedef struct bitstem_fec_decoder bitstem_fec_decoder_t;

/* Lent-buffer Decoder construct. The caller-supplied `lent_buffer`
 * (size lent_len, MUST equal K * T) becomes the decoder's output:
 * AddReceivedSymbol writes source-ESI bytes directly into it,
 * TryDecode reconstructs missing rows in place. The buffer MUST
 * remain valid for every AddReceivedSymbol / TryDecode /
 * source_block call until _destroy or the next _reset_span call.
 *
 * Returns NULL on validation failure (same conditions as
 * encoder_create), size mismatch, or codec not built in. */
BITSTEM_FEC_C_API bitstem_fec_decoder_t*
bitstem_fec_decoder_create(
    const bitstem_fec_params_t* p,
    uint8_t* lent_buffer, size_t lent_len);

BITSTEM_FEC_C_API void bitstem_fec_decoder_destroy(bitstem_fec_decoder_t* dec);

/* Rebind the lent buffer to a new memory region AND clear receive
 * state. The new buffer's size MUST equal K * T. Lets one Decoder
 * instance cycle through many source blocks of the same (K, T,
 * scheme) without paying per-block scratch allocation costs. */
BITSTEM_FEC_C_API void bitstem_fec_decoder_reset_span(
    bitstem_fec_decoder_t* dec,
    uint8_t* lent_buffer, size_t lent_len);

/* Feed one received symbol. `sym_len` MUST equal T. Bytes are
 * interpreted per params.layout (sub-block-major or source-order).
 *
 * As of ABI v1 (libfec >= 0.12.1), receiving the K-th distinct
 * source ESI auto-finalises: subsequent _is_decoded calls return
 * 1 without requiring _try_decode. */
BITSTEM_FEC_C_API void bitstem_fec_decoder_add_received_symbol(
    bitstem_fec_decoder_t* dec,
    uint32_t esi,
    const uint8_t* sym, size_t sym_len);

/* Run the matrix-solve path (or short-circuit if already
 * auto-finalised via lossless K-of-K reception). Returns 1 on
 * success — the lent buffer now holds the K source symbols.
 * Returns 0 if the receive set is rank-deficient; feeding more
 * symbols and retrying may succeed. */
BITSTEM_FEC_C_API int bitstem_fec_decoder_try_decode(bitstem_fec_decoder_t* dec);

/* Returns 1 iff the lent buffer holds the K recovered source
 * symbols. Cheap; auto-finalise lets callers poll this from the
 * receive path without invoking matrix-solve work. */
BITSTEM_FEC_C_API int bitstem_fec_decoder_is_decoded(const bitstem_fec_decoder_t* dec);

/* Read-only view of the lent buffer's bytes. *out_ptr is set to
 * the same address that was lent at _create / _reset_span;
 * *out_len is set to K * T. Available for callers that prefer to
 * read through the API rather than retaining the lent-buffer
 * pointer they handed in. Pre-condition: _is_decoded is true.
 * Asserted in debug. */
BITSTEM_FEC_C_API void bitstem_fec_decoder_source_block(
    const bitstem_fec_decoder_t* dec,
    const uint8_t** out_ptr, size_t* out_len);

/* ------------------------------------------------------------------
 * Build-time codec probe
 *
 * Returns 1 if this libfec.so was compiled with support for the
 * given scheme, 0 otherwise. Lets a runtime-load consumer detect
 * stripped-codec builds (e.g. an SMPTE-2022-only libfec.so deployed
 * to a 5GM transmit path) without trying _create and parsing NULL.
 * ------------------------------------------------------------------ */
BITSTEM_FEC_C_API int bitstem_fec_has_scheme(bitstem_fec_scheme_t scheme);

#ifdef __cplusplus
}  /* extern "C" */
#endif

#endif  /* BITSTEM_FEC_FEC_C_H */
