/*  Copyright (C) Bitstem GmbH
 *  All rights reserved.
 *
 *  This source code is proprietary and confidential.
 *  Unauthorized copying, distribution, or disclosure of this file,
 *  in whole or in part, is strictly prohibited unless explicitly
 *  permitted in writing by Bitstem GmbH.
 *
 *  Author: Klaus Kuehnhammer <klaus@bitstem.com>
 */

/* C ABI for the streaming-FEC layer that implements TS 26.346
 * §8.2.2 (RFC 6363 FECFRAME with the RFC 6681 §6 R10 inner code).
 *
 * Mirrors the C++ surface in <bitstem/fec/streaming.hpp>; the
 * deployment shape and rationale are the same as
 * <bitstem/fec/fec_c.h>: the consumer (5gr-core's RTP / streaming
 * session handler) builds against this header without taking a
 * link-time dependency on libfec.so, dlopens libfec.so.0 at first
 * FEC use, dlsyms the entry points, and calls through function
 * pointers. C linkage is the standard portable pattern for this.
 *
 * Visibility / ABI versioning is shared with fec_c.h —
 * BITSTEM_FEC_C_ABI_VERSION covers both surfaces (the streaming
 * functions are new exports in the same BITSTEM_FEC_0 version tag,
 * additive, no version bump). The streaming-side ABI version
 * tracks alongside.
 *
 * Visit bitstem_fec_c_abi_version() before resolving anything in
 * this header, the same way you would for fec_c.h.
 */

#ifndef BITSTEM_FEC_STREAMING_C_H
#define BITSTEM_FEC_STREAMING_C_H

#include <stddef.h>
#include <stdint.h>

#include "bitstem/fec/fec_c.h"   /* BITSTEM_FEC_C_API macro */

#ifdef __cplusplus
extern "C" {
#endif

/* ------------------------------------------------------------------
 * FEC OTI (TS 26.346 §8.2.2.10a; first 4 octets of FSSI in RFC
 * 6681 §6.2.1.2). Field order matches wire layout: T then MSBL.
 * Note that 26.346 §8.2.2.10a lists the same logical fields in
 * reverse (MSBL-then-T) in prose; this struct follows wire to
 * keep the codec direction unambiguous.
 * ------------------------------------------------------------------ */
typedef struct {
    uint16_t T;        /* Symbol size in octets */
    uint16_t MSBL;     /* Maximum Source Block Length, in symbols */
} bitstem_fec_streaming_oti_t;

/* Result of OnSourcePacket / OnRepairPacket. Mirrors
 * bitstem::fec::streaming::Receiver::FeedResult. */
typedef enum {
    BITSTEM_FEC_FEED_ACCEPTED    = 0,
    BITSTEM_FEC_FEED_STALE_BLOCK = 1,   /* SBN already decoded / evicted */
    BITSTEM_FEC_FEED_INVALID     = 2    /* short SFI/RFI, conflicting SBL, ... */
} bitstem_fec_feed_result_t;

/* Opaque handles. */
typedef struct bitstem_fec_streaming_sender   bitstem_fec_streaming_sender_t;
typedef struct bitstem_fec_streaming_receiver bitstem_fec_streaming_receiver_t;

/* ==================================================================
 * Sender — TS 26.346 §8.2.2.1 sender path.
 * ================================================================== */

/* Construct a per-stream sender for the given OTI.
 *
 * Returns NULL if oti == NULL, oti->T == 0, oti->MSBL == 0, or
 * oti->MSBL is outside the inner R10 codec's K range
 * (MSBL > 8192). Today only R10 (RFC 6681 §6 / TS 26.346 §8.2.2)
 * is supported; if RaptorQ-stream (RFC 6682) is added later, a
 * scheme-selecting Create overload will arrive alongside. */
BITSTEM_FEC_C_API bitstem_fec_streaming_sender_t*
bitstem_fec_streaming_sender_create(
    const bitstem_fec_streaming_oti_t* oti);

BITSTEM_FEC_C_API void
bitstem_fec_streaming_sender_destroy(
    bitstem_fec_streaming_sender_t* s);

/* Append a UDP packet to the in-progress source block. On success
 * returns 1 and writes:
 *   - *out_sbn = SBN this packet sits in (the wire packet's SFI
 *                will carry this SBN).
 *   - *out_esi = first symbol's ESI (the wire packet's SFI will
 *                carry this ESI).
 *   - out_sfi[0..3] = the 4-byte Source FEC Payload ID (RFC 6681
 *                     §6.2.2 Format A) the caller MUST append to
 *                     udp_payload[0..udp_payload_len-1] when
 *                     transmitting the wire source packet.
 *
 * Returns 0 if the packet's framed size would push the in-progress
 * block past MSBL·T. The caller should commit + drain repair, then
 * retry on the fresh block. The buffer is unmodified on rejection.
 *
 * Returns -1 on invalid arguments (NULL handle, NULL out_*,
 * udp_payload_len > 65535). */
BITSTEM_FEC_C_API int
bitstem_fec_streaming_sender_add_packet(
    bitstem_fec_streaming_sender_t* s,
    uint8_t flow_id,
    const uint8_t* udp_payload, size_t udp_payload_len,
    uint16_t* out_sbn, uint16_t* out_esi,
    uint8_t out_sfi[4]);

/* Finalise the in-progress block: pads to the next symbol
 * boundary, sets K_actual = ceil(used_bytes / T), constructs the
 * inner R10 encoder.
 *
 * Returns 1 on success, 0 on empty block or K below the inner
 * codec's K_min (4 for R10) — the caller can keep calling
 * _add_packet and retry. Returns -1 on NULL handle. */
BITSTEM_FEC_C_API int
bitstem_fec_streaming_sender_commit_block(
    bitstem_fec_streaming_sender_t* s);

/* Emit one repair packet. Writes the wire bytes (6-octet RFI per
 * RFC 6681 §6.2.3 Format A + T octets of repair symbol per RFC
 * 6363 §5.4) to out_buf and returns the byte count (6 + T).
 *
 * Returns 0 if no repair packet is available (sender not
 * committed, ESI space exhausted, or out_buf too small to hold
 * the 6 + T bytes — out_buf_len < 6 + T).
 *
 * Returns -1 on NULL handle / NULL out parameters.
 *
 * On success, also writes:
 *   - *out_sbn = the block's SBN.
 *   - *out_esi = this repair symbol's ESI (= K_actual on the
 *                first repair, K_actual + 1 on the second, ...).
 *   - *out_sbl = K_actual for this block (the SBL field in the
 *                RFI). Receiver learns K_actual from this. */
BITSTEM_FEC_C_API ptrdiff_t
bitstem_fec_streaming_sender_emit_repair(
    bitstem_fec_streaming_sender_t* s,
    uint16_t* out_sbn, uint16_t* out_esi, uint16_t* out_sbl,
    uint8_t* out_buf, size_t out_buf_len);

/* Inspectors. Return 0 / 0xFFFF / 0 on NULL handle. */
BITSTEM_FEC_C_API uint16_t
bitstem_fec_streaming_sender_current_sbn(
    const bitstem_fec_streaming_sender_t* s);

BITSTEM_FEC_C_API uint16_t
bitstem_fec_streaming_sender_k_actual(
    const bitstem_fec_streaming_sender_t* s);

BITSTEM_FEC_C_API int
bitstem_fec_streaming_sender_is_committed(
    const bitstem_fec_streaming_sender_t* s);

/* ==================================================================
 * Receiver — TS 26.346 §8.2.2.2 receiver path.
 * ================================================================== */

/* Construct a per-stream receiver. max_inflight_blocks bounds
 * memory: at saturation, the oldest in-flight block is evicted
 * before a new SBN is admitted. Default in the C++ API is 16;
 * pass 0 here to use it.
 *
 * Returns NULL on NULL oti, oti->T == 0, oti->MSBL == 0, or
 * MSBL out of the inner codec's K range. */
BITSTEM_FEC_C_API bitstem_fec_streaming_receiver_t*
bitstem_fec_streaming_receiver_create(
    const bitstem_fec_streaming_oti_t* oti,
    size_t max_inflight_blocks);

BITSTEM_FEC_C_API void
bitstem_fec_streaming_receiver_destroy(
    bitstem_fec_streaming_receiver_t* r);

/* Feed a wire source packet. wire = original UDP payload + 4-octet
 * SFI (per RFC 6363 §5.3 + RFC 6681 §6.2.2 Format A); the caller
 * must have classified it as a source packet via UDP destination
 * port (per SDP UDP/MBMS-FEC/RTP/AVP) and looked up flow_id from
 * the SDP a=mbms-flowid mapping (TS 26.346 §8.3.1.9).
 *
 * Returns one of bitstem_fec_feed_result_t. The original UDP
 * payload is queued for immediate pass-through delivery via
 * _next_delivery. */
BITSTEM_FEC_C_API int
bitstem_fec_streaming_receiver_on_source_packet(
    bitstem_fec_streaming_receiver_t* r,
    uint8_t flow_id,
    const uint8_t* wire, size_t wire_len);

/* Feed a wire repair packet. wire = 6-octet RFI + T octets of
 * repair symbol. Returns one of bitstem_fec_feed_result_t.
 * Repair packets do not produce immediate deliveries; their
 * arrival may trigger a TryDecode of the inflight block, in
 * which case any FEC-recovered packets are queued. */
BITSTEM_FEC_C_API int
bitstem_fec_streaming_receiver_on_repair_packet(
    bitstem_fec_streaming_receiver_t* r,
    const uint8_t* wire, size_t wire_len);

/* Pull the next queued delivery (pass-through or FEC-recovered).
 *
 * Return values:
 *   1  — success. *out_flow_id, *out_was_fec_recovered, and the
 *        first *out_payload_len bytes of out_buf are populated.
 *   0  — delivery queue is empty. Out parameters unchanged.
 *  -1  — out_buf_len is too small for the next entry. The entry
 *        is NOT consumed; the caller can retry with a larger
 *        buffer. *out_payload_len is set to the required size.
 *  -2  — NULL handle / NULL out parameters.
 *
 * For the common path (out_buf sized to the local MTU, e.g.
 * 1500 bytes), only 1 and 0 are observed. */
BITSTEM_FEC_C_API int
bitstem_fec_streaming_receiver_next_delivery(
    bitstem_fec_streaming_receiver_t* r,
    uint8_t* out_flow_id,
    int* out_was_fec_recovered,
    uint8_t* out_buf, size_t out_buf_len,
    size_t* out_payload_len);

/* Force-expire all in-flight blocks whose first packet arrived
 * more than `older_than_ms` milliseconds before now (now =
 * steady_clock::now() inside libfec.so at call time).
 *
 * Source packets from expired blocks have already been delivered
 * (pass-through is immediate); FEC-recoverable packets that
 * hadn't decoded yet are dropped silently.
 *
 * Convenience over the C++ ExpireOlderThan(time_point) which
 * takes an absolute time_point — clock translation across the C
 * boundary is non-portable, so the C ABI uses an offset-from-now
 * the receiver applies internally. */
BITSTEM_FEC_C_API void
bitstem_fec_streaming_receiver_expire_older_than_ms(
    bitstem_fec_streaming_receiver_t* r,
    uint64_t older_than_ms);

BITSTEM_FEC_C_API size_t
bitstem_fec_streaming_receiver_inflight_block_count(
    const bitstem_fec_streaming_receiver_t* r);

#ifdef __cplusplus
}
#endif

#endif  /* BITSTEM_FEC_STREAMING_C_H */
