/*  Copyright (C) Bitstem GmbH
 *  All rights reserved.
 *
 *  This source code is proprietary and confidential.
 *  Unauthorized copying, distribution, or disclosure of this file,
 *  in whole or in part, is strictly prohibited unless explicitly
 *  permitted in writing by Bitstem GmbH.
 *
 *  Author: Klaus Kuehnhammer <klaus@bitstem.com>
 */

#pragma once

#include "bitstem/fec/fec.hpp"

#include <array>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <span>

// Streaming FEC layer: per-stream Sender / Receiver shapes that
// implement the MBMS streaming-FEC protection per 3GPP TS 26.346
// §8.2.2 (= RFC 6363 FECFRAME with the R10 / RFC 6681 FEC ID 1
// inner code).
//
// Sits one protocol layer above the bitstem::fec::fast::Encoder /
// Decoder block-codec surface in fec.hpp. Composes:
//
//   1. UDP-payload packing into a K·T source block per §8.2.2.7
//      ([F: 1B][L: 2B][payload][zero pad to next symbol]).
//   2. SFI / RFI Format A wire codecs per RFC 6681 §6.2.
//   3. fast::Encoder / fast::Decoder for the inner R10 work.
//
// Streaming FEC is independent of file-delivery FEC; this header
// is the consumer surface for streaming session handlers (typically
// 5gr-core's RTP / SRTP path) and bypasses libflute (which is for
// FLUTE / file delivery only).
//
// Phase 3 of the §8.2.2 fold-in adds Sender; Receiver follows in
// phase 4.

namespace bitstem::fec::streaming {

// FEC Object Transmission Information for an MBMS streaming
// session, per TS 26.346 §8.2.2.10a (= first 4 octets of FSSI in
// RFC 6681 §6.2.1.2, Format A).
//
// Field order matches the wire layout: T (octets) first, MSBL
// (symbols) second. Note that 26.346 §8.2.2.10a lists the same
// logical fields in the opposite (MSBL-then-T) order in prose;
// this struct follows wire order to keep the codec direction
// unambiguous.
struct OtiParams {
    std::uint16_t T;       // Symbol size in octets
    std::uint16_t MSBL;    // Maximum Source Block Length, in symbols
};

// What Sender::AddPacket returns. The 4 SFI octets that the wire
// source packet carries appended after the original UDP payload
// (per RFC 6363 §5.3 + RFC 6681 §6.2.2 Format A); plus the (sbn,
// esi) pair the SFI encodes, broken out for caller bookkeeping.
//
// The caller is expected to transmit the wire source packet as
// the original UDP payload concatenated with these 4 SFI octets —
// either via memcpy into a tx buffer, or via sendmsg + iovec for
// zero-copy.
struct SourcePacketOut {
    std::uint16_t            sbn;
    std::uint16_t            esi;
    std::array<std::byte, 4> sfi_bytes;
};

// What Sender::EmitRepairPacket returns. wire_bytes is the full
// repair packet's UDP payload — 6 octets of RFI (RFC 6681 §6.2.3
// Format A) followed by one T-octet repair symbol. The span
// aliases an internal Sender buffer and is invalidated by the
// next AddPacket / CommitBlock / EmitRepairPacket call.
struct RepairPacketOut {
    std::uint16_t              sbn;
    std::uint16_t              esi;
    std::uint16_t              sbl;     // = K_actual for this block
    std::span<const std::byte> wire_bytes;
};

namespace detail {
class SenderImpl;
}  // namespace detail

// Per-stream sender. Construct once per (T, MSBL) combination
// signalled in SDP, then drive it from the streaming session's
// transmit path:
//
//   for each UDP packet to be FEC-protected:
//     auto out = sender.AddPacket(flow_id, payload);
//     if (out) {
//         // Transmit `payload` followed by `out->sfi_bytes` as
//         // the wire source packet's UDP payload.
//     } else {
//         sender.CommitBlock();
//         while (auto rep = sender.EmitRepairPacket()) {
//             // Transmit rep->wire_bytes as the wire repair
//             // packet's UDP payload.
//             if (sent_enough_repair) break;
//         }
//         out = sender.AddPacket(flow_id, payload);
//         // ...
//     }
//
// The number of repair packets to emit per block is up to the
// caller — driven by the target FEC overhead from SDP. Sender
// imposes no minimum.
//
// Not thread-safe. One Sender per stream / sender thread.
class BITSTEM_FEC_API Sender {
 public:
    // Returns nullopt for pathological OTI (T == 0 or MSBL == 0)
    // or if the underlying R10 codec rejects the K range
    // (MSBL > 8192). Today the only supported scheme is R10
    // (FEC Encoding ID 1 per RFC 6681 §6); future RaptorQ-stream
    // (RFC 6682) support would arrive as an additional Create
    // overload.
    static std::optional<Sender> Create(OtiParams oti);

    Sender(Sender&&) noexcept;
    Sender& operator=(Sender&&) noexcept;
    ~Sender();
    Sender(const Sender&)            = delete;
    Sender& operator=(const Sender&) = delete;

    // Append a UDP packet to the in-progress source block. The
    // packet's size when framed (3 header octets + payload + zero
    // pad to next symbol boundary) must fit in the remaining
    // K_max·T capacity; if it doesn't, returns nullopt and leaves
    // the block unchanged. The caller should then CommitBlock,
    // drain repair, and retry on the fresh block.
    //
    // Precondition: udp_payload.size() ≤ 65535 (the L field is
    // 16-bit per §8.2.2.7).
    std::optional<SourcePacketOut>
    AddPacket(std::uint8_t flow_id,
              std::span<const std::byte> udp_payload);

    // Finalise the in-progress block. Pads to the next symbol
    // boundary, sets K_actual = ceil(used / T), constructs the
    // inner fast::Encoder for K_actual, and binds it to the
    // packed block bytes.
    //
    // Returns false if the block is empty (no AddPacket calls
    // since the last commit) or if K_actual is below the inner
    // codec's minimum K (4 for R10). On false return the block
    // remains in-progress and the caller can keep adding packets
    // before re-trying the commit. On true return EmitRepairPacket
    // becomes callable.
    bool CommitBlock();

    // After CommitBlock returned true, pull one repair packet at
    // a time. Each call advances the repair ESI: the first repair
    // ESI is K_actual, the second K_actual + 1, etc. Returns
    // nullopt if not committed, or once ESI has run past 65535
    // (the SFI / RFI ESI field is u16).
    //
    // The returned wire_bytes span aliases an internal sender
    // buffer; invalidated by the next AddPacket / CommitBlock /
    // EmitRepairPacket call.
    std::optional<RepairPacketOut> EmitRepairPacket();

    // True iff CommitBlock was called and the inner encoder has
    // been bound to the source-block bytes. Resets to false on
    // the next AddPacket (which starts a fresh block).
    bool IsBlockCommitted() const noexcept;

    OtiParams      Oti()        const noexcept;
    std::uint16_t  CurrentSbn() const noexcept;  // SBN of the in-progress block
    std::uint16_t  KActual()    const noexcept;  // 0 until CommitBlock

 private:
    explicit Sender(std::unique_ptr<detail::SenderImpl> impl) noexcept;
    std::unique_ptr<detail::SenderImpl> _impl;
};

// What Receiver::NextDelivery returns. udp_payload aliases an
// internal Receiver buffer; valid until the next NextDelivery
// call (the Receiver advances its current-delivery slot on each
// pull).
struct RecoveredPacket {
    std::uint8_t                 flow_id;
    std::span<const std::byte>   udp_payload;
    // True if this packet was reconstructed via FEC; false if it
    // was received as a wire source packet (pass-through).
    bool                         was_fec_recovered;
};

namespace detail {
class ReceiverImpl;
}  // namespace detail

// Per-stream receiver. Construct once per (T, MSBL) combination
// signalled in SDP, then drive it from the streaming session's
// receive path:
//
//   when a UDP packet arrives:
//     classify by destination port (per SDP):
//       SOURCE flow (one of the FEC-protected RTP / RTCP / SRTP /
//                    MIKEY ports):
//         flow_id = mapped from port via SDP
//         recv.OnSourcePacket(flow_id, udp_payload);
//       REPAIR flow (UDP/MBMS-REPAIR per 26.346 §8.2.2.5):
//         recv.OnRepairPacket(udp_payload);
//
//     while (auto p = recv.NextDelivery()) {
//         // Hand p->udp_payload up to the RTP / RTCP / MIKEY
//         // stack; flow_id picks the destination handler. Upper
//         // layer (RTP) is responsible for sequence-number
//         // re-ordering across pass-through + recovered packets.
//     }
//
//   periodically (e.g. once per RTP playout-clock tick):
//     recv.ExpireOlderThan(now - min_buffer_time);
//
// Source packets are delivered immediately as they arrive (low-
// latency pass-through). FEC-recovered packets emerge later, once
// the block decodes — typically after the first repair packet
// arrives and the receiver has accumulated ≥ K_actual symbols.
//
// Not thread-safe. One Receiver per stream / receive thread.
class BITSTEM_FEC_API Receiver {
 public:
    enum class FeedResult : std::uint8_t {
        kAccepted,
        kStaleBlock,   // packet for an already-decoded or evicted SBN
        kInvalid,      // wire-format violation: short SFI/RFI, etc.
    };

    // Returns nullopt for pathological OTI (T == 0 or MSBL == 0)
    // or if the underlying R10 codec rejects the K range
    // (MSBL > 8192). max_inflight_blocks bounds memory: at
    // saturation, the oldest in-flight block is evicted before a
    // newly-arriving SBN is admitted.
    static std::optional<Receiver>
    Create(OtiParams oti, std::size_t max_inflight_blocks = 16);

    Receiver(Receiver&&) noexcept;
    Receiver& operator=(Receiver&&) noexcept;
    ~Receiver();
    Receiver(const Receiver&)            = delete;
    Receiver& operator=(const Receiver&) = delete;

    // Feed a wire source packet. wire_bytes = original UDP payload
    // followed by 4-byte SFI per RFC 6363 §5.3 + RFC 6681 §6.2.2
    // Format A. flow_id is the receiver's mapping of the UDP
    // destination port to the integer F field used in the source-
    // block packing — same value the sender used. The mapping is
    // signalled per SDP (a=mbms-flowid in 26.346 §8.3.1.9).
    //
    // The original UDP payload is delivered to NextDelivery
    // immediately; its bytes are also retained in the inflight
    // block's source-block buffer for use as a source symbol if
    // FEC decoding is needed later.
    //
    // Convenience overload uses steady_clock::now for the block's
    // first-seen timestamp; OnSourcePacketAt allows the caller to
    // supply its own clock value (useful for tests + caller-driven
    // playout pacing).
    FeedResult OnSourcePacket(std::uint8_t flow_id,
                              std::span<const std::byte> wire_bytes);
    FeedResult OnSourcePacketAt(std::uint8_t flow_id,
                                std::span<const std::byte> wire_bytes,
                                std::chrono::steady_clock::time_point now);

    // Feed a wire repair packet. wire_bytes = 6-byte RFI followed
    // by exactly T octets of repair-symbol data (RFC 6363 §5.4 +
    // RFC 6681 §6.2.3 Format A; one repair symbol per packet for
    // v1).
    //
    // Repair packets do not produce immediate deliveries; their
    // arrival may trigger a TryDecode of the inflight block, in
    // which case any FEC-recovered packets are queued for
    // subsequent NextDelivery calls.
    FeedResult OnRepairPacket(std::span<const std::byte> wire_bytes);
    FeedResult OnRepairPacketAt(std::span<const std::byte> wire_bytes,
                                std::chrono::steady_clock::time_point now);

    // Pull the next queued packet, or nullopt when the queue is
    // empty. udp_payload aliases an internal Receiver buffer that
    // is valid until the next NextDelivery call.
    std::optional<RecoveredPacket> NextDelivery();

    // Force-expire all inflight blocks whose first packet arrived
    // strictly before `threshold`. Source packets from those
    // blocks have already been delivered (pass-through is
    // immediate); any FEC-recoverable packets that haven't been
    // decoded yet are dropped silently.
    void ExpireOlderThan(std::chrono::steady_clock::time_point threshold);

    OtiParams   Oti()                  const noexcept;
    std::size_t InflightBlockCount()   const noexcept;
    std::size_t MaxInflightBlocks()    const noexcept;

 private:
    explicit Receiver(std::unique_ptr<detail::ReceiverImpl> impl) noexcept;
    std::unique_ptr<detail::ReceiverImpl> _impl;
};

}  // namespace bitstem::fec::streaming
