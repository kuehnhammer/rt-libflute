/*  Copyright (C) Bitstem GmbH
 *  All rights reserved.
 *
 *  This source code is proprietary and confidential.
 *  Unauthorized copying, distribution, or disclosure of this file,
 *  in whole or in part, is strictly prohibited unless explicitly
 *  permitted in writing by Bitstem GmbH.
 *
 *  Author: Klaus Kuehnhammer <klaus@bitstem.com>
 */

/* Auto-generated from cmake/config.h.in at CMake configure time.
 * Reflects the codec set this libfec build was compiled against.
 *
 * Consumers can `#if defined(BITSTEM_FEC_HAS_R10)` etc. to gate code
 * paths at compile time. Alternatively, runtime probing via
 * `bitstem_fec_has_scheme()` (in fec_c.h) covers dlopen-based
 * loading where the build config of the loaded .so isn't known
 * until after dlsym.
 *
 * Both knobs report the same answer for the loaded library; pick
 * whichever is more ergonomic for the consumer's deployment shape.
 *
 * If a codec is NOT compiled in, the corresponding define is absent
 * from this header, and at runtime:
 *   - bitstem::fec::fast::Encoder/Decoder::Create with the disabled
 *     scheme returns std::nullopt.
 *   - bitstem_fec_encoder_create / decoder_create with the disabled
 *     scheme returns NULL.
 *   - bitstem_fec_has_scheme(disabled) returns 0. */

#ifndef BITSTEM_FEC_CONFIG_H
#define BITSTEM_FEC_CONFIG_H

#define BITSTEM_FEC_HAS_R10
#define BITSTEM_FEC_HAS_RAPTORQ
/* #undef BITSTEM_FEC_HAS_SMPTE2022 */

#endif  /* BITSTEM_FEC_CONFIG_H */
