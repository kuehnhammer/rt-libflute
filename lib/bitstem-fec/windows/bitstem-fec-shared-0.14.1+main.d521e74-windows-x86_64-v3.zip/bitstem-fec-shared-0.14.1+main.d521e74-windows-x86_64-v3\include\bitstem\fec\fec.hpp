/*  Copyright (C) Bitstem GmbH
 *  All rights reserved.
 *
 *  This source code is proprietary and confidential.
 *  Unauthorized copying, distribution, or disclosure of this file,
 *  in whole or in part, is strictly prohibited unless explicitly
 *  permitted in writing by Bitstem GmbH.
 *
 *  Author: Klaus Kuehnhammer <klaus@bitstem.com>
 */

// Public API for the bitstem-fec RFC 5053 (Raptor) FEC library.
//
// Binary-distribution-friendly: this header transitively includes
// no bitstem/fec/internal/* subheader. The two publicly-supported
// types are bitstem::fec::fast::Encoder and bitstem::fec::fast::-
// Decoder, PIMPL-wrapped so the implementation details (precoding
// matrix layout, decoding schedule representation, intermediate-
// symbol buffer ownership) stay inside the static archive and out
// of the consumer's compile graph.
//
// Threading model: each Encoder / Decoder is single-threaded — one
// per consumer thread. The library does maintain a process-wide
// per-K decoding-schedule cache that IS thread-safe (shared_mutex
// internally), so multiple threads constructing same-K Encoders
// concurrently is supported and amortises the schedule-build cost.

#pragma once

// Auto-generated config header — produced by CMake configure_file()
// from cmake/config.h.in. Reflects which codecs were compiled into
// this build (BITSTEM_FEC_HAS_R10 / _HAS_RAPTORQ / _HAS_SMPTE2022).
// Consumers use these defines to gate code paths at compile time;
// the same information is available at runtime via fec_c.h's
// bitstem_fec_has_scheme().
#include "bitstem/fec/config.h"

#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <span>

// Visibility marker for symbols intended to be reachable from
// outside the library. Internal-only symbols are compiled with
// -fvisibility=hidden (see CMakeLists.txt) and therefore not
// reachable from a consumer's link line.
//
// Three build modes are supported:
//   * Static archive (libfec.a) — BITSTEM_FEC_API expands to nothing
//     on Windows; on POSIX it stays "default" visibility, harmless
//     in static linkage.
//   * Shared library, our build side — BITSTEM_FEC_BUILDING_SHARED
//     is defined on the fec_shared target's compile line, switching
//     Windows to __declspec(dllexport) and POSIX to default
//     visibility (the rest of the library is hidden via the target's
//     CXX_VISIBILITY_PRESET=hidden).
//   * Shared library, consumer side — BITSTEM_FEC_USING_SHARED is
//     forwarded via the fec_shared target's INTERFACE compile defs
//     so consumers building against the shared library see
//     __declspec(dllimport) on Windows. On POSIX the macro expands
//     to default visibility, which is the linker's default for
//     consumer-side symbol references anyway.
#if defined(_WIN32) || defined(__CYGWIN__)
  #if defined(BITSTEM_FEC_BUILDING_SHARED)
    #define BITSTEM_FEC_API __declspec(dllexport)
  #elif defined(BITSTEM_FEC_USING_SHARED)
    #define BITSTEM_FEC_API __declspec(dllimport)
  #else
    #define BITSTEM_FEC_API
  #endif
#elif defined(__GNUC__) || defined(__clang__)
  #define BITSTEM_FEC_API __attribute__((visibility("default")))
#else
  #define BITSTEM_FEC_API
#endif

namespace bitstem::fec {

inline constexpr std::uint32_t kLibraryVersionMajor = 0;
inline constexpr std::uint32_t kLibraryVersionMinor = 1;
inline constexpr std::uint32_t kLibraryVersionPatch = 0;

// Selects the FEC scheme used by Encoder / Decoder. The default
// (R10) preserves backward compatibility with consumers that don't
// care about the choice; passing kRaptorQ etc. picks the matching
// codec underneath. Wire-level FEC scheme identifiers (RFC 5052
// IANA registry) are deliberately NOT used here — this enum is a
// codec-selection knob, not a wire identifier.
enum class Scheme : std::uint8_t {
    kR10     = 0,    // RFC 5053 Raptor (R10). K range [4, 8192].
    kRaptorQ = 1,    // RFC 6330 RaptorQ. K range [1, 56403].
};

// Selects the byte layout of the K * T-byte source-block buffer
// the caller hands to / receives from the codec. Only meaningful
// for N>1 (sub-block interleaving); for N==1 the two layouts
// coincide and this knob is a no-op.
//
// kCodecNative: RFC 5053 §5.3.1.2 / RFC 6330 §4.4.1.2 source-block
// layout — N contiguous sub-blocks, each holding K contiguous
// T_i-byte sub-symbols. Sub-block i's K * T_i bytes occupy a
// contiguous run starting at byte sum_{j<i}(K * T_j). This is
// what cberner/raptorq's reference RaptorQ Encoder consumes /
// decoder produces; it's the layout the codec computes
// natively and therefore the cheapest contract on the codec
// side.
//
// kSourceOrder: K source symbols of T bytes each, contiguous
// in source-symbol order — i.e. source symbol e occupies bytes
// [e * T, (e + 1) * T). For N>1 each T-byte symbol is the
// concatenation of N sub-symbols. This is the file-natural
// layout: a flat byte stream with the source bytes in the same
// order they'd appear in the delivered file. The codec
// interleaves / de-interleaves at the wrapper boundary on the
// caller's behalf — one K * T memcpy per Reset / TryDecode.
//
// Pick kSourceOrder when the buffer you're handing the codec is
// already in delivery order (e.g. a slice of a contiguous file
// buffer); pick kCodecNative when you want to skip the wrapper
// memcpy and either pre-interleave on your side or operate on
// the codec's native layout directly. For N==1 either choice
// has identical behaviour and identical cost (no transpose
// either way).
enum class LayoutHint : std::uint8_t {
    kCodecNative = 0,
    kSourceOrder = 1,
};

// Encoder configuration. Bundles the params Encoder::Create
// needs in one struct so callers don't have to thread them as
// positional arguments. New fields land here as the codec gains
// configuration knobs (currently scheme + Al + N; legacy K and T
// duplicated as positional for source-compat with existing
// callers).
//
// Field semantics:
//   * K            — source-symbol count. Must be in the
//                    selected scheme's valid range.
//   * T            — symbol size in bytes. T must be a multiple
//                    of `Al` (RFC 5053 §3.1.1, RFC 6330 §3.1).
//   * scheme       — codec selection (R10 vs RaptorQ, etc).
//   * Al           — symbol alignment (RFC 6330 default 4).
//                    For N=1 the alignment is informational only
//                    (T % Al == 0 is still validated). For N>1
//                    Al is load-bearing: each sub-symbol's size
//                    is a multiple of Al, with the layout
//                    determined by Partition(T/Al, N). Mismatched
//                    Al between encoder and decoder corrupts the
//                    bytestream.
//   * N            — sub-block count (RFC 5053 §5.3.1.2 /
//                    RFC 6330 §4.4.1.2). Splits each T-byte symbol
//                    into N sub-symbols encoded independently.
//                    Valid range: [1, T/Al].
struct EncoderParams {
    std::uint16_t K      = 0;
    std::uint16_t T      = 0;
    Scheme        scheme = Scheme::kR10;
    std::uint8_t  Al     = 4u;
    std::uint16_t N      = 1u;
    // Source-block buffer layout the encoder will read from. See
    // LayoutHint. Default kCodecNative preserves the layout
    // contract that pre-LayoutHint callers (and the cberner KAT
    // suite) rely on. N==1 callers can ignore this — the two
    // layouts coincide.
    LayoutHint    layout = LayoutHint::kCodecNative;
};

// Decoder configuration — same shape as EncoderParams. Encoder
// and decoder MUST agree on every field for a successful round-
// trip; carrying both via the FEC OTI (per RFC 5053 §3.2 / RFC
// 6330 §3.3.2) is what keeps them in sync end-to-end. The
// .layout field is NOT carried over the wire — it's an in-
// process choice about the in-memory representation. Sender
// and receiver may pick different .layout values independently
// (the codec interleaves / de-interleaves on each side as
// needed to match its native layout).
struct DecoderParams {
    std::uint16_t K      = 0;
    std::uint16_t T      = 0;
    Scheme        scheme = Scheme::kR10;
    std::uint8_t  Al     = 4u;
    std::uint16_t N      = 1u;
    LayoutHint    layout = LayoutHint::kCodecNative;
};

namespace fast {

namespace detail {
class EncoderImpl;
class DecoderImpl;
}  // namespace detail

// RFC 5053 §5 encoder. Encodes K source symbols of `symbol_size`
// bytes each into source ESIs (= the source bytes themselves, by
// §5.4.4.3 systematic property) and repair ESIs (linear
// combinations of intermediate symbols).
//
// Lifecycle:
//   - Create(K, T) once per (K, symbol_size). Allocates the L*T
//     intermediate-symbols buffer, fetches the per-K schedule from
//     the process-wide cache (or builds + inserts on first use).
//   - Reset(source) any number of times to bind a new source-
//     symbol set. Zero-fills the constraint region (~S+H rows,
//     a few hundred KB at K=8000) and replays the cached schedule
//     on the new source. Reuses the existing buffer — no
//     allocation, no kernel page-fault path on cache-warm calls.
//   - EncodeSymbol(esi, out) any number of times after Reset to
//     produce the bytes for source ESI `esi < K` or repair ESI
//     `esi >= K`.
//
// The cross-block / cross-file reuse path (HLS / DASH segment
// encoding at stable K) is the principal optimisation target: the
// Reset call is ~40 % cheaper than a fresh Create because the
// 12 MB-class intermediate buffer doesn't have to be allocated +
// page-faulted-in per block.
class BITSTEM_FEC_API Encoder {
 public:
    // Allocate the intermediate buffer + fetch the cached schedule
    // for K. Returns std::nullopt for K outside the selected
    // scheme's valid range, or if `scheme` is not yet implemented.
    // The default (Scheme::kR10) preserves compatibility with
    // callers from before the multi-scheme split.
    static std::optional<Encoder>
    Create(std::uint16_t K, std::size_t symbol_size,
           Scheme scheme = Scheme::kR10);

    // Convenience: Create + Reset in one shot. `source_symbols`
    // must be exactly K * symbol_size bytes. Returns std::nullopt
    // for out-of-range K, wrong source size, or unimplemented
    // scheme.
    static std::optional<Encoder>
    Create(std::uint16_t K,
           std::span<const std::byte> source_symbols,
           std::size_t symbol_size,
           Scheme scheme = Scheme::kR10);

    // Param-struct overloads. Same semantics as the positional
    // versions but bundle the codec config (scheme + Al + N + ...)
    // in a single value the caller can carry through OTI parsing,
    // copy-construct, etc. Returns nullopt if:
    //   - K outside scheme range
    //   - T == 0 or T % params.Al != 0
    //   - params.Al not in {1, 2, 4, 8}
    //   - params.N == 0 or params.N > params.T / params.Al
    //   - source_symbols.size() != K * T  (the with-source form).
    //
    // For N > 1, the encoder partitions each T-byte symbol into N
    // sub-symbols per RFC 5053 §5.3.1.2 / RFC 6330 §4.4.1.2 (with
    // Partition(T/Al, N) determining the per-sub-block byte
    // sizes), and runs the codec independently on each sub-block.
    // Each sub-block solve sees the same K, the same scheme, and
    // the same received-ESI set, so the decoder reassembly is
    // deterministic from the wire bytestream.
    //
    // The caller's Al is load-bearing under N > 1: the sub-block
    // byte boundaries are determined by Al, and the receiver must
    // see the same Al via the FEC OTI to slice incoming symbols
    // identically. We honor params.Al verbatim — it is never
    // derived from K, T, or any other matrix property.
    static std::optional<Encoder>
    Create(const EncoderParams& params);

    static std::optional<Encoder>
    Create(const EncoderParams& params,
           std::span<const std::byte> source_symbols);

    Encoder(Encoder&&) noexcept;
    Encoder& operator=(Encoder&&) noexcept;
    ~Encoder();

    Encoder(const Encoder&) = delete;
    Encoder& operator=(const Encoder&) = delete;

    // Bind a new source-symbol set; must be exactly K * symbol_size
    // bytes. May be called any number of times on the same Encoder.
    void Reset(std::span<const std::byte> source_symbols);

    // Produce the bytes for encoding-symbol ID `esi`. `out_symbol`
    // must be exactly symbol_size bytes. For `esi < K` this is the
    // source symbol verbatim (per RFC 5053 §5.4.4.3); for
    // `esi >= K` it is a repair symbol.
    void EncodeSymbol(std::uint32_t esi,
                      std::span<std::byte> out_symbol) const;

    std::uint16_t K()          const noexcept;
    std::size_t   SymbolSize() const noexcept;

 private:
    explicit Encoder(std::unique_ptr<detail::EncoderImpl> impl) noexcept;
    std::unique_ptr<detail::EncoderImpl> _impl;
};

// RFC 5053 §5.5 decoder. Receives encoding symbols (any mix of
// source ESIs in [0, K) and repair ESIs >= K), recovers the K
// source symbols once enough have arrived. Construct one per
// source block, call AddReceivedSymbol for each received
// (esi, bytes) pair, then TryDecode when the receive set is
// believed to be sufficient.
//
// TryDecode returns false if the matrix is rank-deficient — feed
// more symbols and try again. For the common lossless case (every
// source ESI received) TryDecode short-circuits to a permute-by-
// ESI memcpy (~K*T bytes) and skips the matrix-inversion pipeline
// entirely — the source bytes are already the receiver's output
// per the systematic property.
class BITSTEM_FEC_API Decoder {
 public:
    // The `scheme` last param mirrors Encoder::Create. Default
    // Scheme::kR10 preserves the pre-multi-scheme call shape.
    // This overload assumes Al = 4 and N = 1; use the
    // DecoderParams overload below for explicit Al / N control.
    static std::optional<Decoder>
    Create(std::uint16_t K, std::size_t symbol_size,
           Scheme scheme = Scheme::kR10);

    // Param-struct overload. Mirrors Encoder::Create(EncoderParams).
    // Returns nullopt if:
    //   - K outside scheme range
    //   - T == 0 or T % params.Al != 0
    //   - params.Al not in {1, 2, 4, 8}
    //   - params.N == 0 or params.N > T / Al
    //
    // For N>1 the decoder internally partitions each received T-byte
    // symbol into N sub-symbols (RFC 5053 §5.3.1.2 / RFC 6330
    // §4.4.1.2), runs the codec independently on each sub-block,
    // and reassembles the K * T source-block output.
    //
    // This overload allocates an internal K * params.T-byte output
    // buffer; SourceBlock() returns a span over it. For the
    // zero-extract-copy lent-buffer model, use the overload below.
    static std::optional<Decoder>
    Create(const DecoderParams& params);

    // Lent-buffer overload. Identical to Create(params) except the
    // caller supplies the K * params.T-byte output buffer; the
    // decoder writes recovered source bytes (received via
    // AddReceivedSymbol AND reconstructed by TryDecode) directly
    // into that buffer, never duplicating them in any internal
    // scratch.
    //
    // Lifetime contract: `output_buffer` MUST remain valid for the
    // duration of every AddReceivedSymbol / TryDecode / SourceBlock
    // call on this Decoder, until the next Reset(span) replaces it
    // or the Decoder is destroyed. The Decoder retains the span by
    // value (pointer + size); no ownership transfer.
    //
    // Size contract: output_buffer.size() MUST equal
    // K * params.T. Returns nullopt on size mismatch (in addition
    // to the conditions of Create(params)).
    //
    // Layout contract: bytes inside output_buffer are in the
    // codec's source-block layout — for N==1 this is "K source
    // symbols of T bytes each, contiguous"; for N>1 it is the
    // sub-block-major layout per RFC 5053 §5.3.1.2 / RFC 6330
    // §4.4.1.2 (N contiguous sub-blocks, each holding K
    // contiguous T_i-byte sub-symbols).
    //
    // Aliasing contract: the caller must NOT read or write
    // output_buffer between the first AddReceivedSymbol and the
    // last successful TryDecode for a given decode pass. Reads
    // are safe after TryDecode returns true. Concurrent Decoders
    // sharing distinct, non-overlapping slices of a larger buffer
    // (e.g. one Decoder per source block of a file laid out
    // contiguously) are safe.
    static std::optional<Decoder>
    Create(const DecoderParams& params,
           std::span<std::byte> output_buffer);

    Decoder(Decoder&&) noexcept;
    Decoder& operator=(Decoder&&) noexcept;
    ~Decoder();

    Decoder(const Decoder&) = delete;
    Decoder& operator=(const Decoder&) = delete;

    // Clear receive state. Pre-allocated scratch (RaptorQ's
    // dense-matrix Phase-1 scratch, the repair-bytes buffer)
    // is retained — subsequent AddReceivedSymbol + TryDecode
    // calls reuse it. Use this in session-style delivery (HLS
    // / DASH segment streams) to skip per-block allocation +
    // page-fault costs on the warm path.
    //
    // For lent-buffer Decoders: the previously-bound output
    // buffer span is kept; the next decode will write into it
    // exactly as the previous one did. To rebind to a fresh
    // output buffer (typical: each source block of a multi-block
    // file gets its own slice), use Reset(span) below.
    //
    // R10 path: clears receive state; no per-block scratch to
    // retain (R10's decode is lighter-weight).
    void Reset();

    // Rebind the lent output buffer for the next decode AND clear
    // receive state (= Reset() + new span). Allows one Decoder
    // instance to cycle through many source blocks of the same
    // (K, T, scheme) without paying per-block allocation costs —
    // the per-K' Phase-1 scratch and the schedule cache stay
    // warm across calls.
    //
    // Same lifetime / size / layout / aliasing contracts as
    // Create(params, output_buffer). Calling on a Decoder that
    // was constructed without a lent buffer (i.e. Create(params)
    // form) is well-defined: the Decoder switches to lent-buffer
    // mode for subsequent decodes; the previously-allocated
    // internal output vector is freed.
    //
    // Precondition: output_buffer.size() == K * symbol_size.
    // Asserts in debug builds; undefined in release on size
    // mismatch (caller responsibility).
    void Reset(std::span<std::byte> output_buffer);

    void AddReceivedSymbol(std::uint32_t esi,
                           std::span<const std::byte> symbol);

    // Returns true on success; the K * symbol_size source bytes are
    // then accessible via SourceBlock(). Returns false if the
    // receive set is rank-deficient — additional AddReceivedSymbol
    // calls + a retry may succeed.
    bool TryDecode();

    bool IsDecoded() const noexcept;

    // K * symbol_size bytes of the recovered source block. Only
    // meaningful after TryDecode has returned true.
    //
    // For lent-buffer Decoders: the returned span aliases the
    // caller-supplied buffer; the bytes ARE the lent buffer.
    // For internal-buffer Decoders: the returned span aliases
    // the Decoder's private vector; valid until the next Reset
    // or Decoder destruction.
    std::span<const std::byte> SourceBlock() const;

    std::uint16_t K()          const noexcept;
    std::size_t   SymbolSize() const noexcept;

 private:
    explicit Decoder(std::unique_ptr<detail::DecoderImpl> impl) noexcept;
    std::unique_ptr<detail::DecoderImpl> _impl;
};

}  // namespace fast
}  // namespace bitstem::fec
