/*  Copyright (C) Bitstem GmbH
 *  All rights reserved.
 *
 *  This source code is proprietary and confidential.
 *  Unauthorized copying, distribution, or disclosure of this file,
 *  in whole or in part, is strictly prohibited unless explicitly
 *  permitted in writing by Bitstem GmbH.
 *
 *  Author: Klaus Kuehnhammer <klaus@bitstem.com>
 */

/* Stable C ABI for cross-language harnesses — used by:
 *   - tools/sweep (Rust integration test that cross-validates our
 *     impl against cberner/raptorq across the K' parameter space).
 *   - rq bench (planned, parallel to R10's tools/fec_bench.cpp).
 * Internal use only — not part of the public binary distribution.
 * The C++ public API in <bitstem/fec/fec.hpp> remains the supported
 * surface for downstream consumers.
 */

#ifndef BITSTEM_FEC_C_API_H
#define BITSTEM_FEC_C_API_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ------------------------------------------------------------------- */
/* RaptorQ (RFC 6330) reference encoder                                */
/* ------------------------------------------------------------------- */

typedef struct bitstem_rq_encoder bitstem_rq_encoder_t;

/* Construct an encoder for `K` source symbols of `symbol_size` bytes
 * each. `source` must point to exactly K * symbol_size bytes; the
 * encoder takes a private copy. Returns NULL on invalid input.
 */
bitstem_rq_encoder_t*
bitstem_rq_encoder_create(uint32_t K,
                          const uint8_t* source,
                          size_t source_len,
                          size_t symbol_size);

void
bitstem_rq_encoder_destroy(bitstem_rq_encoder_t* enc);

/* Encode the symbol with the given ESI into `out`. `out_len` MUST
 * equal symbol_size.
 */
void
bitstem_rq_encoder_encode_symbol(const bitstem_rq_encoder_t* enc,
                                 uint32_t esi,
                                 uint8_t* out,
                                 size_t out_len);

/* ------------------------------------------------------------------- */
/* RaptorQ (RFC 6330) reference decoder                                */
/* ------------------------------------------------------------------- */

typedef struct bitstem_rq_decoder bitstem_rq_decoder_t;

bitstem_rq_decoder_t*
bitstem_rq_decoder_create(uint32_t K, size_t symbol_size);

void
bitstem_rq_decoder_destroy(bitstem_rq_decoder_t* dec);

void
bitstem_rq_decoder_add_symbol(bitstem_rq_decoder_t* dec,
                              uint32_t esi,
                              const uint8_t* data,
                              size_t data_len);

/* Returns 1 on success, 0 on rank-deficient. Idempotent. */
int
bitstem_rq_decoder_try_decode(bitstem_rq_decoder_t* dec);

int
bitstem_rq_decoder_is_decoded(const bitstem_rq_decoder_t* dec);

/* Copy K * symbol_size bytes of recovered source into `out`.
 * `out_len` MUST equal K * symbol_size. Returns 1 on success, 0 if
 * not yet decoded.
 */
int
bitstem_rq_decoder_get_source_block(const bitstem_rq_decoder_t* dec,
                                    uint8_t* out,
                                    size_t out_len);

#ifdef __cplusplus
}
#endif

#endif  /* BITSTEM_FEC_C_API_H */
